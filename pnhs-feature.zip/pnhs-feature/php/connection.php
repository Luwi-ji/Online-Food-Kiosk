<?php
$server = "localhost";
$user = "root";
$password = "";
$database = "pnhs_canteen";
$con = mysqli_connect($server, $user, $password, $database) or die("Error in connection");